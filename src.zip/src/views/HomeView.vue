<template>
  <body style="height: 749px width: 694px">
    <div id="header" class="header"></div>
    <div class="Nsearch">
      <div class="search_inner">
        <div class="search_box">
          <div class="search_box_inner">
            <span class="search_text_box">
              <input
                type="search"
                name="search_query"
                value
                maxlength="100"
                placeholder="버스번호, 정류장 검색"
                title="검색어 입력"
                class="search_text"
              />
            </span>
            <span class="box_tool">
              <button type="button" class="box_button2">
                <span class="icon_delete">검색어 삭제</span>
              </button>
              <button type="button" class="search_button">
                <span class="icon_button">검색</span>
              </button>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="search_busbox">
      <div class="search_busbox_list">
        <p class="search_error_msg">
          <span class="search_error_icon_msg"></span>
          최근 검색 기록이 없습니다.
        </p>
      </div>
    </div>
  </body>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      itemList: []
    }
  },
  setup() {},
  created() {
    this.getList()
  },
  mounted() {},
  unmounted() {},
  methods: {
    async getList() {
      console.log(this.itemList)
      this.itemList.push(
        await this.$api(
          'http://ws.bus.go.kr/api/rest/stationinfo/getStationByName?serviceKey=bho4x4eke%2B8rK9bPmWNqp5ZBWlRDMU64nMuChXKseYVWkj%2BL%2BeDjlDRRFitmFP%2BYOJy41bfwbkXckWfHAJvl9g%3D%3D&stSrch=선릉&resultType=json',
          'get'
        ).msgBody.itemList
      )
      console.log(this.itemList)
      this.stNm = await this.$api(
        'http://ws.bus.go.kr/api/rest/stationinfo/getStationByName?serviceKey=bho4x4eke%2B8rK9bPmWNqp5ZBWlRDMU64nMuChXKseYVWkj%2BL%2BeDjlDRRFitmFP%2BYOJy41bfwbkXckWfHAJvl9g%3D%3D&stSrch=선릉&resultType=json',
        'get'
      )
      this.tmX = await this.$api(
        'http://ws.bus.go.kr/api/rest/stationinfo/getStationByName?serviceKey=bho4x4eke%2B8rK9bPmWNqp5ZBWlRDMU64nMuChXKseYVWkj%2BL%2BeDjlDRRFitmFP%2BYOJy41bfwbkXckWfHAJvl9g%3D%3D&stSrch=선릉&resultType=json',
        'get'
      )
      this.tmY = await this.$api(
        'http://ws.bus.go.kr/api/rest/stationinfo/getStationByName?serviceKey=bho4x4eke%2B8rK9bPmWNqp5ZBWlRDMU64nMuChXKseYVWkj%2BL%2BeDjlDRRFitmFP%2BYOJy41bfwbkXckWfHAJvl9g%3D%3D&stSrch=선릉&resultType=json',
        'get'
      )
      this.arsId = await this.$api(
        'http://ws.bus.go.kr/api/rest/stationinfo/getStationByName?serviceKey=bho4x4eke%2B8rK9bPmWNqp5ZBWlRDMU64nMuChXKseYVWkj%2BL%2BeDjlDRRFitmFP%2BYOJy41bfwbkXckWfHAJvl9g%3D%3D&stSrch=선릉&resultType=json',
        'get'
      )
    }
  }
}
</script>
<style scoped>
#header {
  text-align: center;
  color: #fff;
}

.search_text {
  box-sizing: border-box;
  width: 100%;
  height: 42px;
  padding: 0 12px;
  border: 0;
  font-size: 17px;
  color: #000;
  font-weight: bold;
  line-height: 26px;
  background: none;
}

.search_text_box {
  display: table-cell;
  width: 100%;
  vertical-align: top;
}

.search_box_inner {
  display: table;
  width: 100%;
}

.Nsearch {
  position: relative;
  padding: 6px 6px 6px 6px;
  line-height: 14px;
  background-color: #00c73c;
}

.search_box {
  box-sizing: border-box;
  width: 100%;
  vertical-align: top;
  background-color: #fff;
}

.search_inner {
  display: table;
  width: 100%;
}

.box_tool {
  overflow: hidden;
  display: table-cell;
  font-size: 0;
  text-align: right;
  white-space: nowrap;
  vertical-align: top;
}

.box_button2 {
  overflow: hidden;
  position: relative;
  height: 42px;
  margin: 0;
  padding: 0;
  border: 0;
  line-height: 42px;
  vertical-align: top;
  background: none;
  display: none;
}

.icon_delete {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: linear-gradient(transparent, transparent),
    url(https://ssl.pstatic.net/static/maps/m/sp_search.svg);
  background-size: 95px 91px;
  background-repeat: no-repeat;
  width: 18px;
  height: 18px;
  background-position: -34px -40px;
  margin: auto;
  color: transparent;
}

.search_button {
  display: inline-block;
  overflow: hidden;
  position: relative;
  height: 42px;
  width: 42px;
  margin: 0;
  padding: 0;
  border: 0;
  line-height: 42px;
  vertical-align: top;
  background: none;
}

.icon_button {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: linear-gradient(transparent, transparent),
    url(https://ssl.pstatic.net/static/maps/m/sp_search.svg);
  background-size: 95px 91px;
  background-repeat: no-repeat;
  width: 18px;
  height: 18px;
  background-position: -6px -68px;
  margin: auto;
  color: transparent;
}

.search_busbox {
  display: table;
  width: 100%;
  box-sizing: border-box;
  height: 675px;
  margin: 5px 0;
  border-left: 5px solid #e9ecef;
  border-right: 5px solid #e9ecef;
  border-top: 5px solid #e9ecef;
  border-bottom: 5px solid #e9ecef;
  background: #fff;
}

.search_busbox_list {
  position: relative;
  display: table-cell;
  vertical-align: middle;
}

.search_error_msg {
  overflow: hidden;
  color: #aeb3ba;
  font-size: 15px;
  text-align: center;
}
.search_error_icon_msg {
  display: block;
  margin: 0 auto 10px;
  width: 41px;
  height: 41px;
  background-position: 0 -27px;
  overflow: hidden;
  color: transparent;
  vertical-align: top;
  background-image: url(https://ssl.pstatic.net/static/maps/m/sp_map_v78compressed.png);
  background-size: 450px 420px;
  background-repeat: no-repeat;
  text-shadow: none;
}
.search_list_bus {
  display: block;
  padding: 16px 14px 0;
  background-color: #fff;
}
</style>
